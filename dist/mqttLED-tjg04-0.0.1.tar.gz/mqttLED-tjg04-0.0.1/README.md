
# MQTTLED

This package allows control of an OpenWRT device's LEDs over MQTT. Configured using UCI.